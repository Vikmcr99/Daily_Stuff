package com.example.daily_stuff.Model

data class NotesClass (var title : String, var description : String, var isChecked : Boolean = false)
