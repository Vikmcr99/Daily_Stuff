package com.example.daily_stuff.Views

import androidx.fragment.app.Fragment
import com.example.daily_stuff.R


class TodoFragment : Fragment(R.layout.fragment_todo) {

}