package com.example.daily_stuff.Model

data class Todo (val title : String, var isChecked: Boolean = false)
